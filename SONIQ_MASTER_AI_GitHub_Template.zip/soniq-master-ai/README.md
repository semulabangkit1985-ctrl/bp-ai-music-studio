# SONIQ MASTER AI

AI-assisted online mastering platform scaffold for music creators.

## Included
- Next.js frontend
- FastAPI backend
- PostgreSQL + Redis
- Docker Compose
- Upload WAV/FLAC/MP3/AIFF
- Audio analysis
- Vocal-safe mastering plan
- 8 mastering styles
- Basic rendering/QC pipeline
- Presets
- Tests
- GitHub-ready `.gitignore` and environment template

> This repository is an MVP engineering template, not a replacement for LANDR/Ozone-grade DSP. Production mastering requires a high-quality DSP engine, proper true-peak limiting/oversampling, deeper psychoacoustic analysis, authentication hardening, storage security, migrations, billing, and extensive listening tests.

## Quick start

1. Copy `.env.example` to `.env`.
2. Run:

```bash
docker compose up --build
```

3. Open:
- Frontend: http://localhost:3000
- API docs: http://localhost:8000/docs

## GitHub

```bash
git init
git add .
git commit -m "Initial SONIQ MASTER AI template"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/soniq-master-ai.git
git push -u origin main
```

## Vocal preservation

The mastering pipeline does not pitch-shift, formant-shift, time-stretch, replace, or clone the singer. Vocal protection limits aggressive processing around the vocal region.

## Next production steps
1. Replace the demo renderer with a dedicated mastering DSP engine.
2. Add Alembic migrations.
3. Add production authentication and signed download URLs.
4. Add object storage.
5. Add reference mastering and A/B loudness matching.
6. Add subscriptions/payment.
7. Add GPU/ML analysis where useful.

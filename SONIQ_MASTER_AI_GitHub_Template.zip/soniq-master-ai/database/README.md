# Database

The MVP creates tables automatically on startup.

For production, replace this with Alembic migrations and a controlled schema/versioning process.

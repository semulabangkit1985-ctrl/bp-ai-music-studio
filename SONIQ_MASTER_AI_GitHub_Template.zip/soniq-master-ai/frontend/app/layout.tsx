import "./globals.css";

export const metadata = {
  title: "SONIQ MASTER AI",
  description: "AI-assisted music mastering",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}

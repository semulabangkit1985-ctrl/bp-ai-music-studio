 "use client";

import { useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const styles = ["Universal","Natural","Clarity","Tape","Punch","Fire","Spatial","Cinematic"];

export default function Home() {
  const [userId, setUserId] = useState("1");
  const [file, setFile] = useState<File | null>(null);
  const [audioId, setAudioId] = useState<number | null>(null);
  const [style, setStyle] = useState("Natural");
  const [message, setMessage] = useState("Ready.");

  async function upload() {
    if (!file) return setMessage("Choose an audio file first.");
    const form = new FormData();
    form.append("user_id", userId);
    form.append("file", file);
    const res = await fetch(`${API}/audio/upload`, { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) return setMessage(data.detail || "Upload failed");
    setAudioId(data.audio_id);
    setMessage(`Uploaded: ${data.filename}`);
  }

  async function master() {
    if (!audioId) return setMessage("Upload a track first.");
    const res = await fetch(`${API}/master`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({audio_id: audioId, style})
    });
    const data = await res.json();
    setMessage(res.ok ? `Master job #${data.job_id} queued.` : (data.detail || "Master failed"));
  }

  return (
    <main className="container">
      <h1>SONIQ MASTER AI</h1>
      <p className="muted">AI-assisted mastering • Vocal Safe • Original Mix Preservation</p>

      <section className="card">
        <h2>1. Upload</h2>
        <input type="number" value={userId} onChange={e => setUserId(e.target.value)} />
        <br /><br />
        <input type="file" accept=".wav,.flac,.mp3,.aiff,.aif" onChange={e => setFile(e.target.files?.[0] || null)} />
        <br /><br />
        <button className="primary" onClick={upload}>Upload Track</button>
      </section>

      <section className="card">
        <h2>2. Mastering Style</h2>
        <div className="grid">
          {styles.map(s => (
            <button key={s} className={style === s ? "primary" : ""} onClick={() => setStyle(s)}>{s}</button>
          ))}
        </div>
      </section>

      <section className="card">
        <h2>3. Master</h2>
        <p>Selected: <b>{style}</b></p>
        <button className="primary" onClick={master}>START AI MASTERING</button>
        <p className="muted">{message}</p>
      </section>
    </main>
  );
}

# Tests

Run backend tests inside the backend environment:

```bash
pytest
```

Add regression tests for:
- clipping
- true peak
- loudness
- vocal-region protection
- stereo correlation
- reference matching
- export integrity

from app.engine.vocal_safe import vocal_safety_profile

def test_original_vocal_is_preserved():
    profile = vocal_safety_profile({})
    assert profile["pitch_change"] is False
    assert profile["formant_change"] is False
    assert profile["time_stretch"] is False
    assert profile["voice_replacement"] is False
    assert profile["preserve_original_mix"] is True
